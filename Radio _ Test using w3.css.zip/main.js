const open = document.getElementById("open")
const close = document.getElementById("close")
const modal = document.getElementById("modal")

function openModal() {
  modal.style.display = "block"
}
open.onclick = openModal

function closeModal() {
  modal.style.display = "none"
}
close.onclick = closeModal


const radio1 = document.getElementById("radio1")
const playLush = document.getElementById("playLush")

function playRadio1() {
  if (radio1.paused == true) {
    radio1.play()
    playLush.innerText = "Pause"
  } else if (radio1.paused == false) {
    radio1.pause()
    playLush.innerText = "Play"
  }
}
playLush.onclick = playRadio1

const radio2 = document.getElementById("radio2")
const playU80s = document.getElementById("playU80s")

function playRadio2() {
  if (radio2.paused == true) {
    radio2.play()
    playU80s.innerText = "Pause"
  } else if (radio2.paused == false) {
    radio2.pause()
    playU80s.innerText = "Play"
  }
}
playU80s.onclick = playRadio2

const radio3 = document.getElementById("radio3")
const playDeepSpaceOne = document.getElementById("playDeepSpaceOne")

function playRadio3() {
  if (radio3.paused == true) {
    radio3.play()
    playDeepSpaceOne.innerText = "Pause"
  } else if (radio3.paused == false) {
    radio3.pause()
    playDeepSpaceOne.innerText = "Play"
  }
}
playDeepSpaceOne.onclick = playRadio3